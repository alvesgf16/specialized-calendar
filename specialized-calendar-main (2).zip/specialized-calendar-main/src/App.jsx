import react, { useState, useEffect } from 'react';
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    fetch('specialized-calendar-main\public\samplemarks.txt.txt')
      .then(response => response.text())
      .then(text => {
        const parsedClasses = parseData(text);
        setClasses(parsedClasses);
      });
  }, []);

  // A basic parser function to transform the text data into objects.
  function parseData(text) {
    const classesData = text.split('\n\n').map(classSection => {
      const lines = classSection.split('\n');
      const classData = {
        name: '',
        grade: '',
        assignments: [],
        date: '',
      };

      lines.forEach(line => {
        if (line.startsWith('Class:')) {
          classData.name = line.replace('Class: ', '');
        } else if (line.startsWith('Grade:')) {
          classData.grade = line.replace('Grade: ', '');
        } else if (line.startsWith('Assignments:')) {
          // Skip this line, as the assignments are listed in the following lines
        } else if (line.startsWith('Date:')) {
          classData.date = line.replace('Date: ', '');
        } else if (line.startsWith('  - Assignment:')) {
          // Parsing assignments
          const assignmentDetails = line.trim().slice(14).split(', ');
          const assignment = {};
          assignmentDetails.forEach(detail => {
            const [key, value] = detail.split(': ');
            assignment[key.toLowerCase()] = value;
          });
          classData.assignments.push(assignment);
        }
      });

      return classData;
    });

    return classesData;
  }

  return (
    <div className="App">
      {classes.map((classItem, index) => (
        <div key={index} className="class-container">
          <h2>{classItem.name}</h2>
          <p>Grade: {classItem.grade}</p>
          <div className="assignments">
            {classItem.assignments.map((assignment, index) => (
              <div key={index} className="assignment">
                <p>{assignment.assignment}</p>
                <p>Weight: {assignment.weight}</p>
                <p>Achieved: {assignment.achieved}</p>
              </div>
            ))}
          </div>
          <p>Date: {classItem.date}</p>
        </div>
      ))}
    </div>
  );
}

export default App;